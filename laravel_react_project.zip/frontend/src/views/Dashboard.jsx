import { Link } from "react-router-dom";
import Carousel from './Carousel';
import Cards from './Cards';


export default function Dashboard(){
    return (
        <div>


             <Carousel />
             <Cards />


        </div>
    );
}
